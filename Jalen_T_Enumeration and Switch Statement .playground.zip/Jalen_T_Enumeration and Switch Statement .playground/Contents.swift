import UIKit

enum sandvich: CaseIterable {
    case wheat_bread
    case bologna_meat
    case tomato
    case lettuce
    case cheese
    case green_olive
}
let number_of_ingredients = sandvich.allCases.count
print("these are \(number_of_ingredients) ingredients needed for sandvich")

for sandvich in sandvich.allCases {
    print("this is how you make Sandvich you need: ")
    print(sandvich)
}
print("you put olive on top of sandvich using a toothpick and now you have made sandvich")
